/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

import Exception.ModeloExistenteException;
import Model.CentroEntrenamiento;
import Model.Modelo;
import Model.RedNeuronal;
import Model.AlgoritmoGenetico;
import Model.ArbolDeDecision;
import Model.TipoDato;


public class GALARZAParcial1322 {

    public static void main(String[] args) {
        CentroEntrenamiento c1 = new CentroEntrenamiento();

        try {
            Modelo m1 = new RedNeuronal("RED NEURONAL", "LAB 1", TipoDato.DATOS_NUMERICOS, 8);
            Modelo m2 = new ArbolDeDecision("ARBOL DE DECISION", "LAB 1", TipoDato.DATOS_NUMERICOS, "ENTROPIA");
            Modelo m3 = new AlgoritmoGenetico("ALGORITMO GENETICO", "LAB 1", TipoDato.DATOS_NUMERICOS, 6.0);
            Modelo m4 = new AlgoritmoGenetico("ARBOL DE DECISION 2", "LAB 1", TipoDato.DATOS_TEXTUALES, 5.0);
            Modelo m5 = new RedNeuronal("RED NEURONAL", "LAB 1", TipoDato.DATOS_NUMERICOS, 8); // CON ESTE LANZAMOS EXCEPTION REPETIDO.
            
            System.out.println("=== MODELOS AGREGADOS CORRECTAMENTE. ===");
            
            c1.agregarModelo(m1);
            c1.agregarModelo(m2);
            c1.agregarModelo(m3);
            c1.agregarModelo(m4); // SI SACAMOS ESTE NO SE MUESTRAN ENTRENABLES TIPO TEXTUALES
            c1.agregarModelo(m5); // LANZAMOS EXCEPCION
            
            
        } catch (ModeloExistenteException ex) {
            System.out.println("ERROR AL AGREGAR MODELO: " + ex.getMessage());
        }
        
        
        // MOSTRAMOS MODELOS
        System.out.println("=== MOSTRANDO MODELOS... ===\n");
        c1.mostrarModelos();
        
        // ENTRENAMOS LOS MODELOS
        System.out.println("\n=== ENTRENANDO MODELOS POSIBLES... ===\n");
        c1.entrenarModelos();
        
        // FILTRAMOS MODELO NUMERICO
        System.out.println("\n=== TIPOS DE MODELO NUMERICOS REGISTRADOS. ===\n");
        c1.filtrarPorTipoDatos(TipoDato.DATOS_NUMERICOS);
        
        // FILTRAMOS MODELO TEXTUALES
        System.out.println("\n=== TIPOS DE MODELO TEXTUALES REGISTRADOS. ===\n");
        c1.filtrarPorTipoDatos(TipoDato.DATOS_TEXTUALES);

    }

}