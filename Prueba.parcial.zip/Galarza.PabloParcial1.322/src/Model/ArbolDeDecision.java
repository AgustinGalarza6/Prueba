/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Interface.Entrenable;

/**
 *
 * @author Agust
 */
public class ArbolDeDecision extends Modelo implements Entrenable{
    
    private final String tipoDeCriterio;

    public ArbolDeDecision(String nombreIdentificador, String laboratorioAsignado, TipoDato tipoDato, String tipoDeCriterio) {
        super(nombreIdentificador, laboratorioAsignado, tipoDato);
        validarCriterioDivision(tipoDeCriterio);
        this.tipoDeCriterio = tipoDeCriterio;
    }
    
    private void validarCriterioDivision(String tipoDeCriterio){
        if(tipoDeCriterio == ""){
            throw new IllegalArgumentException("POR FAVOR INGRESE UN CRITERIO.");
        }
    }
    
    
    @Override
    public void entrenar() {
        System.out.println("ARBOL DE DECISION: " + getNombreIdentificador() + " EN PROCESO DE ENTRENAMIENTO.");
    }
    
    @Override
    public String toString() {
        return super.toString() + ", TIPO DE CRITERIO: " + tipoDeCriterio;
    }
    
}
