/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Exception.ModeloExistenteException;
import Interface.Entrenable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Agust
 */
public class CentroEntrenamiento {
    
    private final List<Modelo> modelos;

    public CentroEntrenamiento() {
        this.modelos = new ArrayList<>();
    }
    
    public void agregarModelo(Modelo modelo){
        if (modelo == null) {
            throw new NullPointerException("MODELO NULA.");
        }

        if (this.modelos.contains(modelo)) {
            throw new ModeloExistenteException();
        }

        modelos.add(modelo);
    }
    
    public void validarSiHayModelos(){
        if(modelos.isEmpty()){
            throw new IllegalArgumentException("NO HAY MODELOS.");
        }
    }   
    
    public void mostrarModelos(){
        validarSiHayModelos();
        for(Modelo mod : modelos){
            System.out.println(mod);
        }
    }
    
    
    public void entrenarModelos(){
        for(Modelo mod : modelos){
            if(mod instanceof Entrenable){
                ((Entrenable) mod).entrenar();
            } else {
                System.out.println(mod.getNombreIdentificador() + " NO ES ENTRENABLE.");
            }
        }
    }
    
    
    public List<Modelo> filtrarPorTipoDatos(TipoDato tipo) {
            List<Modelo> filtrados = new ArrayList<>();

            for (Modelo m : modelos) {
                if (m.getTipoDato() == tipo) {
                    filtrados.add(m);
                    System.out.println(m);
                    System.out.println("--------------------------");
                }
            }
        return filtrados;
    }
    
}
