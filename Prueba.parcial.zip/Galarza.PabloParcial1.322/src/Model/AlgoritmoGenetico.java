/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Agust
 */
public class AlgoritmoGenetico extends Modelo{
    
    private final double tasaMutacion;

    public AlgoritmoGenetico(String nombreIdentificador, String laboratorioAsignado, TipoDato tipoDato, double tasaMutacion) {
        super(nombreIdentificador, laboratorioAsignado, tipoDato);
        validarTasaMutacion(tasaMutacion);
        this.tasaMutacion = tasaMutacion;
    }
    
    
    private void validarTasaMutacion(double tasaMutacion){
        if(tasaMutacion < 0){
            throw new IllegalArgumentException("LA TASA DE MUTACION NO PUEDE SER MENOR A 0.");
        }
    }
    
    
    @Override
    public String toString() {
        return super.toString() + ", TASA DE MUTACION: " + "%" + tasaMutacion;
    }
}
