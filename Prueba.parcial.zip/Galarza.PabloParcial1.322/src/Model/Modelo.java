/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.Objects;

/**
 *
 * @author Agust
 */
public abstract class Modelo {
    
    private final String nombreIdentificador;
    private final String laboratorioAsignado;
    private final TipoDato tipoDato;

    public Modelo(String nombreIdentificador, String laboratorioAsignado, TipoDato tipoDato) {
        this.nombreIdentificador = nombreIdentificador;
        this.laboratorioAsignado = laboratorioAsignado;
        this.tipoDato = tipoDato;
    }

    public String getNombreIdentificador() {
        return nombreIdentificador;
    }


    public TipoDato getTipoDato() {
        return tipoDato;
    }

    
    @Override
    public boolean equals(Object obj) {
        
        if (this == obj) return true;
        
        if (obj == null || !(obj instanceof Modelo)){
            return false;
        }

        Modelo other = (Modelo) obj;
        return this.nombreIdentificador.equals(other.nombreIdentificador) &&
               this.laboratorioAsignado.equals(other.laboratorioAsignado);
    }   

    @Override
    public int hashCode() {
        return Objects.hash(nombreIdentificador, laboratorioAsignado);
    }

    @Override
    public String toString() {
        return "Modelo: " + nombreIdentificador + ", Laboratorio: " + laboratorioAsignado +
               ", Tipo de Datos: " + tipoDato;
    }
}